# -*- coding: utf-8 -*-

"""Generate a default configuration-file section for definitive_verify2"""


def config_section_data():
    """
    Produce add the default configuration section to app.config,
    for definitive_verify2 when called by `resilient-circuits config [-c|-u]`
    """
    config_data = None

#    config_data = u"""[definitive_verify2]
#setting=xxx
#"""
    return config_data
